package com.example.hospitalmanagementapp.patient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.hospitalmanagementapp.R;

public class PatientRegister extends AppCompatActivity {

    Button resg;
    private EditText mEmail, mPass, mAge, mAddress, mPhone;
    private Button Reg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_register);
      /*  resg = findViewById(R.id.pat_Register);
        resg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent r = new Intent(PatientRegister.this,PatientLogin.class);
                startActivity(r);
            }
        });*/
        registration();
    }
    private void registration(){
        mEmail = findViewById(R.id.pat_inputEmail);
        mPass = findViewById(R.id.pat_inputPassword);
        mAge = findViewById(R.id.pat_age);
        mAddress = findViewById(R.id.pat_address);
        mPhone = findViewById(R.id.pat_phone);
        Reg = findViewById(R.id.pat_Register);
        Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = mEmail.getText().toString().trim();
                String pass = mPass.getText().toString().trim();
                String age =mAge.getText().toString().trim();
                String address = mAddress.toString().trim();
                String phone = mPhone.toString().trim();
                if(TextUtils.isEmpty(email)){
                    mEmail.setError("Email Required...");
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    mEmail.setError("Pass Required...");
                    return;
                }
                if(TextUtils.isEmpty(age)){
                    mEmail.setError("Age Required...");
                    return;
                }
                if(TextUtils.isEmpty(address)){
                    mEmail.setError("Address Required...");
                    return;
                }
                if(TextUtils.isEmpty(phone)){
                    mEmail.setError("Phone Required...");
                    return;
                }
            }
        });
    }
}