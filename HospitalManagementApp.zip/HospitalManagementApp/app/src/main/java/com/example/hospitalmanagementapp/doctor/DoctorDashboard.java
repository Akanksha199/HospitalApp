package com.example.hospitalmanagementapp.doctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.hospitalmanagementapp.MainPage;
import com.example.hospitalmanagementapp.R;
import com.example.hospitalmanagementapp.patient.AccountFragment;
import com.example.hospitalmanagementapp.patient.AmbulanceFragment;
import com.example.hospitalmanagementapp.patient.AppointmentFragment;
import com.example.hospitalmanagementapp.patient.HealthFragment;
import com.example.hospitalmanagementapp.patient.MedicalStoreFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DoctorDashboard extends AppCompatActivity {

    /*Toolbar toolbar;
    TextView doctext;*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_dashboard);
        BottomNavigationView Navview1 = findViewById(R.id.doctor_bottombar);
        Navview1.setOnNavigationItemSelectedListener(navListner1);
        getSupportFragmentManager().beginTransaction().replace(R.id.doctor_mainframe,new DocAppFragment()).commit();
        /*toolbar = findViewById(R.id.doctor_toolbar);
        doctext = toolbar.findViewById(R.id.doctor_titleText);
        doctext.setText("DashBoard");*/
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListner1 = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;
            switch (item.getItemId()){
                case R.id.doctor_appointment:
                    selectedFragment = new DocAppFragment();
                    break;
                case R.id.doctor_account:
                    selectedFragment = new DocAccFragment();
                    break;
                case R.id.doctor_logout:
                    Intent n = new Intent(getApplicationContext(), MainPage.class);
                    startActivity(n);
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.doctor_mainframe,selectedFragment).commit();

            return true;
        }
    };
}