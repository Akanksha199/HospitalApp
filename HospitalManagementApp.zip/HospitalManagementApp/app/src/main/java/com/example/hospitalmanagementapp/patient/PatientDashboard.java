package com.example.hospitalmanagementapp.patient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.hospitalmanagementapp.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PatientDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_dashboard);
        BottomNavigationView Navview = findViewById(R.id.patient_bottombar);
        Navview.setOnNavigationItemSelectedListener(navListner);
        getSupportFragmentManager().beginTransaction().replace(R.id.patient_mainframe,new AppointmentFragment()).commit();
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;
            switch (item.getItemId()){
                case R.id.patientappoint:
                    selectedFragment = new AppointmentFragment();
                    break;
                case R.id.medicalstore:
                    selectedFragment = new MedicalStoreFragment();
                    break;
                case R.id.Health:
                    selectedFragment = new HealthFragment();
                    break;
                case R.id.ambulance:
                    selectedFragment = new AmbulanceFragment();
                    break;
                case R.id.patient_account:
                    selectedFragment = new AccountFragment();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.patient_mainframe,selectedFragment).commit();

            return true;
        }
    };
}