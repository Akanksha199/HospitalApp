package com.example.hospitalmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.hospitalmanagementapp.doctor.DoctorLogin;
import com.example.hospitalmanagementapp.patient.PatientLogin;

public class MainPage extends AppCompatActivity {

    Button doctor, patient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        doctor = findViewById(R.id.doctor);
        patient = findViewById(R.id.patient);
        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent doc = new Intent(MainPage.this, DoctorLogin.class);
                startActivity(doc);
            }
        });
        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pate = new Intent(MainPage.this, PatientLogin.class);
                startActivity(pate);
            }
        });
    }
}