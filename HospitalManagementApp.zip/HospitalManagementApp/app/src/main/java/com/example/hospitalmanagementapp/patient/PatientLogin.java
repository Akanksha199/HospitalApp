package com.example.hospitalmanagementapp.patient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.hospitalmanagementapp.R;

public class PatientLogin extends AppCompatActivity {

    Button patLogin;
    TextView register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);
        patLogin = findViewById(R.id.pat_btnLogin);
        register = findViewById(R.id.pat_gotoRegister);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent res = new Intent(PatientLogin.this,PatientRegister.class);
                startActivity(res);
            }
        });
        patLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent patlog = new Intent(PatientLogin.this,PatientDashboard.class);
                startActivity(patlog);
            }
        });
    }
}